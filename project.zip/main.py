from PyQt5.QtGui import *
from inputForm import *
from Security import *
import math

class System(QWidget):
    def __init__(self,*args):
        super().__init__()
        self.key1=-1
        self.key2=-1
        self.key3 =-1
        self.key4 =-1
        self.fname= "ERR_NO_FILE"
        self.str="ERR_NO_STR"
        self.mode ="NO"
        self.security = Security()
        #색지정
        self.setAutoFillBackground(True)
        p = self.palette()
        p.setColor(self.backgroundRole(), QColor(255, 255, 255))
        self.setPalette(p)

        #key 박스
        self.keyBoxLayout = QHBoxLayout()
        self.UVkey = QTextBrowser() #공개키
        self.UVkey.setMaximumHeight(27)
        self.key = QTextBrowser() #대칭키
        self.key.setMaximumHeight(27)

        #파일열기
        self.fileOpenBoxLayout = QHBoxLayout()
        self.selectedFile = QTextBrowser()
        self.selectedFile.setMaximumHeight(27)

        #입력
        self.inputBoxLayout = QVBoxLayout()
        self.outputWindow = QTextBrowser()

        self.encodeBTN = QPushButton("암호화")
        self.decodeBTN = QPushButton("복호화")
        self.fOpenBTN = QPushButton("파일열기")
        #버튼 색지정
        style ='QPushButton {background-color: #EAEDED}'
        self.encodeBTN.setStyleSheet(style)
        self.decodeBTN.setStyleSheet(style)
        self.fOpenBTN.setStyleSheet(style)


        #출력
        self.outPutLayout = QVBoxLayout()

        self.setUpUI()

    def initKEYWINDOW(self):
        self.UVkey.setText("")
        self.key.setText("")
    def initFIEL(self):
        self.fname= "ERR_NO_FILE"
        self.str="ERR_NO_STR"

    def initINPUT(self):
        self.key1=-1
        self.key2=-1
        self.key3 =-1
        self.key4 =-1


    def initOUTPUT(self):
        self.outputWindow.setText("")

    def setKey(self,key1,key2,key3,key4,TYPE):
        self.key1=(key1)
        self.key2=key2
        self.key3= key3
        self.key4 = key4

        if TYPE == inputWindow.ENCODE:
            self.UVkey.setText("입력 P: %s / Q: %s / 입력대칭키 %s, %s"%(self.key1,self.key2,self.key3,self.key4))
        elif TYPE == inputWindow.DECODE:
            self.UVkey.setText("입력대칭키 %s, %s" % ( self.key3, self.key4))

    def readFile(self,name):
        str =""
        f = open(name, 'r')
        while True:
            line = f.readline()
            str+=line
            if not line: break
        f.close()
        return str

    ## BTNenvent


    def is_prime(self,n):
        print("함수진입")
        if n % 2 == 0 and n > 2 or n<2:
            print("2의배수")
            return False
        for i in range(3, int(math.sqrt(n)) + 1, 2):
            if n % i == 0:
                print("NO프")
                return False
        print("프라임")
        return True

    def getStringFromList(self,list):
        txt = ""
        for t in list:
            txt += "%s " % t
        return txt
    def getFileName(self):
        temp= self.fname.split("/")
        t=""
        for i in range(len(temp)):
            if i == len(temp)-1:
                t+="/C_"+temp[i]
                break
            if i==0:
                t+=temp[i]
            else:
                t +="/"+ temp[i]
        return t

    def openFileCliked(self):
        self.initINPUT()
        self.initOUTPUT()
        self.initKEYWINDOW()

        name = QFileDialog.getOpenFileName(self)
        self.fname = name[0]
        if self.checkFILE() == False:
            self.selectedFile.setText("파일을 열 수 없는 파일입니다")
            return False

        self.selectedFile.setText(self.fname)
        self.str =self.readFile(self.fname)
        self.outputWindow.setText(self.str)
    def checkINPUT(self):
        if self.key1==-1 and self.key2==-1 and self.key3 ==-1 and self.key4 ==-1:
            self.initKEYWINDOW()
            self.UVkey.setText("입력창 에러발생")#입력창에러
            return False
        elif self.key1=="" and self.key2=="" and self.key3 =="" and self.key4 =="":
            self.initKEYWINDOW()
            self.UVkey.setText("입력창에 값을 입력해주세요") #값입력 x
            return False
        elif self.key3 =="" or self.key4 =="":
            self.initKEYWINDOW()
            self.key.setText("입력창에 값을 입력해주세요") #값입력 x
            return False

        elif self.mode=="ENCODE":
            print("암호화")
            if self.key1 == "" or self.key2 == "":
                self.initKEYWINDOW()
                self.UVkey.setText("입력창에 값을 입력해주세요")  # 값입력 x
                return False

            if (self.is_prime(int(self.key1)) ==False or self.is_prime(int(self.key2)) ==False):
                self.initKEYWINDOW()
                self.UVkey.setText("P와Q는 소수\(1과 자신만 약수로 갖고 있는수\)가 아닙니다")
                return False

            if len(self.key3) != 8 or len(self.key4) != 8:#자리수가 맞지 않다면
                self.initKEYWINDOW()
                self.key.setText("주키와 보조키는 8글자 입니다.")
                return False

        elif self.mode =="DECODE":
            print("복호화")
            if len(self.key3) != 8 or len(self.key4) != 8:#암호화이고 키에러일때
                self.initKEYWINDOW()
                self.key.setText("주키와 보조키는 8글자 입니다.")
                return False


        if  self.fname== "ERR_NO_FILE" or self.str=="ERR_NO_STR":

            self.selectedFile.setText("잘못된 확장자이거나 파일을 열지 않았습니다")
            return False






        return True
    def checkFILE(self):
        if self.fname== "ERR_NO_FILE"or self.fname== '':
            return False
        if self.fname.split(".")[-1]!= 'txt' and self.fname.split(".")[-1]!= 'text':
            return False
        return True
    def writeFILE(self,fname,text):
        with open(fname, "w") as f:
            f.write(text)
    def getIntListFromStringList(self,list,intList):

        for item in list:
            intList.append(int(item.strip()))
            #print(res)

        print("리턴")


    def encodeText(self):
        if self.checkFILE() == False:
            self.selectedFile.setText("파일을 열려있지 않습니다.")
            return False
        self.mode = "ENCODE"
        mywindow = inputWindow(self,inputWindow.ENCODE)
        mywindow.exec_()
        if self.checkINPUT() == False:
            self.mode = "NO"
            return False
        #print("암호화시작")
        item =self.security.encoding(self.str,int(self.key1),int(self.key2),str(self.key3),str(self.key4))
        #print("암호화 완")
        self.key.setText("전달할 n: %s / e: %s / 대칭키 %s, %s" % (item[0], item[1], self.key3, self.key4))
        #print("인포박스 셋")
        res1 =self.getStringFromList(item[0:2])
        res2 =self.getStringFromList(item[2])

        res = res1+res2
        #print("내용얻기 %s"%res)
        self.outputWindow.setText(res)
        #print("아웃풋셋")
        self.writeFILE(self.getFileName(),res)
        #print("파일쓰기완료")
        self.initFIEL()
        self.initINPUT()

    def decodeText(self):

        if self.checkFILE() == False:
            self.selectedFile.setText("파일을 열려있지 않습니다.")
            return False
        self.mode = "DECODE"
        mywindow = inputWindow(self,inputWindow.DECODE)
        mywindow.exec_()
        #print("윈도우꺼지 ")
        if self.checkINPUT() == False:
            self.mode="NO"
            return False
        #print("유효인풋확보")
        item = self.str.split(" ")
        #print(item)
        n = item.pop(0)
        e = item.pop(0)
        item.pop()
        intList = []
        self.getIntListFromStringList(item,intList)

        #print(intList)
        res =self.security.decoding(intList,int(n),int(e),self.key3,self.key4)
        self.key.setText("전달받은 n: %s / e: %s / 대칭키 %s, %s" % (n, e, self.key3, self.key4))
        self.outputWindow.setText(res)
        self.initFIEL()
        self.initINPUT()
        #self.initKEYWINDOW()




    ## UI
    def setUpBTN(self):
        self.encodeBTN.clicked.connect(self.encodeText)
        self.decodeBTN.clicked.connect(self.decodeText)
        self.fOpenBTN.clicked.connect(self.openFileCliked)

    def setUpKeyLayout(self):
        # 키를 입력받는 텍스트 윈도우 관리
        self.keyBoxLayout.addWidget(self.UVkey)
        self.keyBoxLayout.addWidget(self.key)
        self.keyBoxLayout.addWidget(self.encodeBTN)
        self.keyBoxLayout.addWidget(self.decodeBTN)

    def setUpFileLodadLayout(self):
        self.fileOpenBoxLayout.addWidget(self.selectedFile)
        self.fileOpenBoxLayout.addWidget(self.fOpenBTN)

    def setUpInputLayout(self):
        #입력레이아웃
        self.setUpBTN()
        self.setUpKeyLayout()
        self.setUpFileLodadLayout()
        self.inputBoxLayout.addLayout(self.fileOpenBoxLayout)
        self.inputBoxLayout.addLayout(self.keyBoxLayout)

    def setUpOutputLayout(self):
        self.outPutLayout.addWidget(self.outputWindow)

    def setUpUI(self):
        self.setGeometry(800, 500, 800, 500)
        self.setUpInputLayout()
        self.setUpOutputLayout()

        #전체 화면 레이아웃
        fullLayout = QVBoxLayout()
        fullLayout.addLayout(self.inputBoxLayout)
        fullLayout.addLayout(self.outPutLayout)
        self.setLayout(fullLayout)
    ## end UI






if __name__ == "__main__":
    app = QApplication(sys.argv)
    mywindow = System()
    mywindow.show()
    app.exec_()