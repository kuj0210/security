from PyQt5.QtGui import *
from inputForm import *
from Security import *

class System(QWidget):
    def __init__(self,*args):
        super().__init__()
        self.key1=-1
        self.key2=-1
        self.key3 =-1
        self.key4 =-1
        self.fname= "ERR_NO_FILE"
        self.str="ERR_NO_STR"

        self.security = Security()
        #색지정
        self.setAutoFillBackground(True)
        p = self.palette()
        p.setColor(self.backgroundRole(), QColor(255, 255, 255))
        self.setPalette(p)

        #key 박스
        self.keyBoxLayout = QHBoxLayout()
        self.UVkey = QTextBrowser() #공개키
        self.UVkey.setMaximumHeight(27)
        self.key = QTextBrowser() #대칭키
        self.key.setMaximumHeight(27)

        #파일열기
        self.fileOpenBoxLayout = QHBoxLayout()
        self.selectedFile = QTextBrowser()
        self.selectedFile.setMaximumHeight(27)

        #입력
        self.inputBoxLayout = QVBoxLayout()
        self.outputWindow = QTextBrowser()

        self.encodeBTN = QPushButton("암호화")
        self.decodeBTN = QPushButton("복호화")
        self.fOpenBTN = QPushButton("파일열기")
        #버튼 색지정
        style ='QPushButton {background-color: #EAEDED}'
        self.encodeBTN.setStyleSheet(style)
        self.decodeBTN.setStyleSheet(style)
        self.fOpenBTN.setStyleSheet(style)


        #출력
        self.outPutLayout = QVBoxLayout()

        self.setUpUI()

    def initINPUT(self):
        self.key1=-1
        self.key2=-1
        self.key3 =-1
        self.key4 =-1
        self.fname= "ERR_NO_FILE"
        self.str="ERR_NO_STR"
        self.UVkey.setText("")
        self.key.setText("")
        self.outputWindow.setText("")

    def setKey(self,key1,key2,key3,key4,TYPE):
        self.key1=key1
        self.key2=key2
        self.key3= key3
        self.key4 = key4

        if TYPE == inputWindow.ENCODE:
            self.UVkey.setText("입력 P: %s / Q: %s / 입력대칭키 %s, %s"%(self.key1,self.key2,self.key3,self.key4))
        elif TYPE == inputWindow.DECODE:
            self.UVkey.setText("입력 n: %s / d: %s / 입력대칭키 %s, %s" % (self.key1, self.key2, self.key3, self.key4))

    def readFile(self,name):
        str =""
        f = open(name, 'r')
        while True:
            line = f.readline()
            str+=line
            if not line: break
        f.close()
        return str

    ## BTNenvent
    def openFileCliked(self):
        self.initINPUT()
        name = QFileDialog.getOpenFileName(self)
        self.fname = name[0]
        if self.checkFILE() == False:
            return False

        self.selectedFile.setText(self.fname)
        self.str =self.readFile(self.fname)
        self.outputWindow.setText(self.str)



    def getStringFromList(self,list):
        txt = ""
        for t in list:
            txt += "%s " % t
        return txt
    def getFileName(self):
        temp= self.fname.split("/")
        t=""
        for i in range(len(temp)):
            if i == len(temp)-1:
                t+="/C_"+temp[i]
                break
            if i==0:
                t+=temp[i]
            else:
                t +="/"+ temp[i]
        return t
    def checkINPUT(self):
        if self.key1==-1 and self.key2==-1 and self.key3 ==-1 and self.key4 ==-1:
            return False

        if  self.fname== "ERR_NO_FILE" or self.str=="ERR_NO_STR":
            return False

        return True
    def checkFILE(self):
        if self.fname== "ERR_NO_FILE"or self.fname== '':
            return False
        return True

    def encodeText(self):
        if self.checkFILE() == False:
            return False
        mywindow = inputWindow(self,inputWindow.ENCODE)
        mywindow.exec_()
        if self.checkINPUT() == False:
            return False

        item =self.security.encoding(self.str,int(self.key1),int(self.key2),str(self.key3),str(self.key4))
        print("암호화 완")
        self.key.setText("전달할 n: %s / d: %s / 대칭키 %s, %s" % (item[0], item[1], self.key3, self.key4))
        print("인포박스 셋")
        res =self.getStringFromList(item[2])
        print("내용얻기 %s"%res)
        self.outputWindow.setText(res)
        print("아웃풋셋")
        name=self.getFileName()
        with open(name, "w") as f:
            f.write(res)
    def decodeText(self):
        mywindow = inputWindow(self,inputWindow.DECODE)
        mywindow.exec_()






    ## UI
    def setUpBTN(self):
        self.encodeBTN.clicked.connect(self.encodeText)
        self.decodeBTN.clicked.connect(self.decodeText)
        self.fOpenBTN.clicked.connect(self.openFileCliked)

    def setUpKeyLayout(self):
        # 키를 입력받는 텍스트 윈도우 관리
        self.keyBoxLayout.addWidget(self.UVkey)
        self.keyBoxLayout.addWidget(self.key)
        self.keyBoxLayout.addWidget(self.encodeBTN)
        self.keyBoxLayout.addWidget(self.decodeBTN)

    def setUpFileLodadLayout(self):
        self.fileOpenBoxLayout.addWidget(self.selectedFile)
        self.fileOpenBoxLayout.addWidget(self.fOpenBTN)

    def setUpInputLayout(self):
        #입력레이아웃
        self.setUpBTN()
        self.setUpKeyLayout()
        self.setUpFileLodadLayout()
        self.inputBoxLayout.addLayout(self.fileOpenBoxLayout)
        self.inputBoxLayout.addLayout(self.keyBoxLayout)

    def setUpOutputLayout(self):
        self.outPutLayout.addWidget(self.outputWindow)

    def setUpUI(self):
        self.setGeometry(800, 500, 800, 500)
        self.setUpInputLayout()
        self.setUpOutputLayout()

        #전체 화면 레이아웃
        fullLayout = QVBoxLayout()
        fullLayout.addLayout(self.inputBoxLayout)
        fullLayout.addLayout(self.outPutLayout)
        self.setLayout(fullLayout)
    ## end UI






if __name__ == "__main__":
    app = QApplication(sys.argv)
    mywindow = System()
    mywindow.show()
    app.exec_()