from myDES import *
from RSA import *

class Security:
    def encoding(self, text, p, q, iv, key):
        des =DES(iv,key)
        rsa =RSA(p,q)
        #DES 암호화
        res = des.encrypt(text)
        n = rsa.get_n()
        e = rsa.get_public_key()
        d = rsa.get_private_key(e)
        #print("원문 + DES =  %s" % res)

        #RSA 암호화

        res =rsa.encrypt(n, d, res.decode('ascii'))
        #print("원문 + DES + RSA =",res)
        list=[n,e,res]
        return list

    def decoding(self,text,n,e,iv,key):
        des = DES(iv, key)
        rsa = RSA(0, 0)
        res = rsa.decrypt(n,e,text)
        res =res.encode ('ascii')
        res = des.decrypt(iv,key,res)
        return res.decode('ascii')



if __name__ == "__main__":
    p = 7
    q = 37
    iv ="1230000a"
    key = "876000b0"
    s = Security()
    c= s.encoding("it is TESTOR",p,q,iv,key)
    print(c)
    p=s.decoding(c[2],c[0],c[1],iv,key)
    print(p)