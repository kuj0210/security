from myDES import *
from RSA import *

class Security:
    def encoding(self, text, p, q, iv, key):
        des =DES(iv,key)
        rsa =RSA(p,q)
        #DES 암호화
        res = des.encrypt(text)
        n = rsa.get_n()
        e = rsa.get_public_key()
        d = rsa.get_private_key(e)
        #print("원문 + DES =  %s" % res)

        #RSA 암호화

        res =rsa.encrypt(n, e, res.decode('ascii'))
        #print("원문 + DES + RSA =",res)
        list=[n,d,res]
        return list

    def decoding(self,text,n,d,iv,key):
        #print("원문 + DES + RSA =", text)
        des = DES(iv, key)
        #RSA 복호화
        rsa = RSA(0, 0)
        res = rsa.decrypt(n,d,text)
        res =res.encode ('ascii')
        #print("원문 + DES=   %s" %res)
        res = des.decrypt(iv,key,res)
        return res.decode('ascii')



if __name__ == "__main__":
    p = 7
    q = 37
    iv ="1230000a"
    key = "876000b0"
    s = Security()
    c= s.encoding("it is TESTOR",p,q,iv,key)
    print(c)
    p=s.decoding(c[2],c[0],c[1],iv,key)
    print(p)