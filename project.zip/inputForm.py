from PyQt5.QtCore import *
from PyQt5.QtGui import QDropEvent,QDragEnterEvent,QDragLeaveEvent,QDragMoveEvent
from PyQt5.QtWidgets import *
import sys

class inputWindow(QDialog):
    ENCODE=10
    DECODE=20
    def __init__(self,p,TYPE):
        super().__init__()
        self.p = p
        self.type=TYPE
        self.btn = QPushButton("확인용")
        self.input1=QLineEdit()
        self.input2 = QLineEdit()
        self.input3 = QLineEdit()
        self.input4 = QLineEdit()
        self.setUpUI(self.type)
        self.btn.clicked.connect(self.distroy)

    def distroy(self):
        key1=self.input1.text()
        key2 = self.input2.text()
        key3 = self.input3.text()
        key4 = self.input4.text()
        self.p.setKey(key1,key2,key3,key4,self.type)
        self.close()

    def setUpUI(self,TYPE):
        self.setGeometry(300, 75, 300, 75)
        #전체 화면 레이아웃
        LabelBox=QHBoxLayout()
        TextBox=QHBoxLayout()


        UVLavel1 = QLabel()
        UVLavel2 = QLabel()

        KeyLavel1 = QLabel()
        KeyLavel2 = QLabel()
        LabelBox.addWidget(UVLavel1)
        LabelBox.addWidget(UVLavel2)
        LabelBox.addWidget(KeyLavel1)
        LabelBox.addWidget(KeyLavel2)
        if TYPE == inputWindow.ENCODE:
            UVLavel1.setText("랜덤값")
            UVLavel2.setText("서로소 값")
            KeyLavel1.setText("주키(8)")
            KeyLavel2.setText("보조키(8)")
        else:
            UVLavel1.setText("n")
            UVLavel2.setText("d")
            KeyLavel1.setText("주키(8)")
            KeyLavel2.setText("보조키(8)")


        TextBox.addWidget(self.input1)
        TextBox.addWidget(self.input2)
        TextBox.addWidget(self.input3)
        TextBox.addWidget(self.input4)

        fullLayout = QVBoxLayout()
        fullLayout.addLayout(LabelBox)
        fullLayout.addLayout(TextBox)
        fullLayout.addWidget(self.btn)
        self.setLayout(fullLayout)






