class RSA:
    def __init__(self,p,q):
        self.m = "non input"
        self.p = p
        self.q = q
        self.n = p*q
        self.PI= (p-1) * (q-1)

        self.e = 0
        self.d =0

    def gcd(self, a, b):
        while b != 0:
            a, b = b, a % b
        return a

    def get_n(self):
        return self.n

    def get_private_key(self, e):
        d = 1
        while (e * d) % self.PI!= 1 or d == e:
            d += 1
        self.d = d
        return d

    def get_public_key(self):
        e = 2
        while e < self.PI and self.gcd(e, self.PI) != 1:
            e += 1
        self.e = e
        return e

   #list 형태의 암호화 값들
    def decrypt(self, n, d, ciphertext):
        plain = [chr((char ** d) % n) for char in ciphertext] #chr : 아스키->알파벳
                                                                                               #암호화된 문장의 숫자들을 꺼내서
        return ''.join(plain)                                                        #아스키값을 복호화해서 문장화

    def encrypt(self, n, e, plaintext):
        cipher = [(ord(char) ** e) % n for char in plaintext] #ord(char) 아스키코드 **(제곱)
        return cipher

    def show_all(self):         # 전체 확인용 초기메세지 "non input"사용
        print("\n\ne = ", self.e, "   d = ", self.d)
        print("original msg : ", self.m)
        en_msg = self.encrypt(self.e, self.m)
        de_msg = self.decrypt(self.d, en_msg)
        print("encrypt msg : ", en_msg)
        print("decrypt msg : ", de_msg)
        return

    def get_key(self):
        print("\n\nget key\n(p, q, n, e, d) : (", self.p, self.q, self.n, self.e, self.d, ")")
        return self.p, self.q, self.n, self.e, self.d

if __name__ == "__main__":
    p=17
    q=37
    ras = RSA(p, q)
    ras1 = RSA(0, 0)
    n = ras.get_n()
    e = ras.get_public_key()
    d = ras.get_private_key(e)
    print("e : ", e, " d : ", d)
    TestMSG = "This is security project"
    print("Ori_MSG : ", TestMSG)
    testEMSG = ras.encrypt(n, d, TestMSG)
    print("En_MSG : ",testEMSG)
    print("De_MSG : ",ras1.decrypt(n, e, testEMSG))